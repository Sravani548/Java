CSCI-185 Programming II

ATM Project coded in Java.
#
Status: <b>COMPLETE</b>
#
Description: This project was to make an automated teller machine with user's account and password, bank account, with that user are able to withdraw, deposit, and view their account balance. Everything is done using command line.

Predefined account and password:

Account #:  123456789
Password #: 1234

Account #: 123456789
Password #: 1230
